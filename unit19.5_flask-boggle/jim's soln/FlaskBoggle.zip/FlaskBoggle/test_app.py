from unittest import TestCase
from app import app
from flask import session
from boggle import Boggle


MyBoard = [
    ['C', 'A', 'T', 'S', 'F'],
    ['C', 'A', 'T', 'S', 'L'],
    ['C', 'A', 'T', 'S', 'E'],
    ['C', 'A', 'T', 'S', 'A'],
    ['C', 'A', 'T', 'S', 'F']
]


class BoggleTestCase(TestCase):

    def test_home(self):
        with app.test_client() as client:
            response = client.get('/')
        self.assertEqual(response.status_code, 200)
        html = response.get_data(as_text=True)
        self.assertIn("<h1>Jim's Boggle World</h1>", html)

    
    def test_check_word(self):
        with app.test_client() as client:
            with client.session_transaction() as change_session:
                change_session['board'] = MyBoard

            # Check word that's there
            response = client.get('/check-word?word=flea')
            result = response.get_json()
            self.assertEqual(result['status'], 'ok')

            # Check gibberish
            response = client.get('/check-word?word=foobaz')
            result = response.get_json()
            self.assertEqual(result['status'], 'not-a-word')

            # Check word that's not there
            response = client.get('/check-word?word=intestine')
            result = response.get_json()
            self.assertEqual(result['status'], 'not-on-board')


    def test_record_game(self):
        with app.test_client() as client:
            with client.session_transaction() as change_session:
                change_session['board'] = []
                change_session['game_count'] = 3
                change_session['high_score'] = 10
            
            # Low score & game count
            response = client.post('/record-game', json={ 'score': 7 })
            result = response.get_json()
            self.assertEqual(result['game_count'], 4)
            self.assertEqual(result['high_score'], 10)

            # New high score
            response = client.post('/record-game', json={ 'score': 23 })
            result = response.get_json()
            self.assertEqual(result['game_count'], 5)
            self.assertEqual(result['high_score'], 23)
