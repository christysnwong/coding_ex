/* boggle.js */

/**
 * Flask Boggle | Springboard SEC Track, Project 19.05.15
 * Jim Rudolf | rudolf@jbrcodes.com
 * Updated: 11 Feb 2021
 */

'use strict';

/******************************************************************************
 * Constants & Globals
 *****************************************************************************/

const START_SECONDS = 60;

const STATUS_MESSAGES = {
    'ok': 'Good word!',
    'not-on-board': 'Word not on board',
    'not-a-word': 'Not a word',
    'already-used': 'Word already used'
}

let Score = 0;
let WordHistory = [];

/******************************************************************************
 * Functions
 *****************************************************************************/

function updateScoreboard(word, result) {
    document.getElementById('score').textContent = Score;
    document.getElementById('sb-word').textContent = word;
    document.getElementById('sb-history').textContent = WordHistory.join(' ');

    let status = STATUS_MESSAGES[result];
    if (result === 'ok') {
        status += ` ${word.length} point(s)!`;
    }
    document.getElementById('sb-status').textContent = status;
}

async function checkWord(word) {
    // Have we already accepted the word?
    if (WordHistory.includes(word)) {
        updateScoreboard(word, 'already-used');
        return;
    }

    // Ask server to check word
    let url = 'http://localhost:5000/check-word?word=' + word;
    let response = await axios.get(url);
    if (response.status !== 200) {
        console.log(`ERROR checkWord: ${response.status} ${response.statusText}`);
        return;
    }

    // Record it if it's a new word
    let status = response.data.status;
    if (status === 'ok') {
        Score += word.length;
        WordHistory.push(word);
    }

    // Inform user
    updateScoreboard(word, status);
}

async function recordGame(score) {
    let url = 'http://localhost:5000/record-game';
    let data = { score: score };
    let response = await axios.post(url, data);
    if (response.status !== 200) {
        console.log(`ERROR recordGame: ${response.status} ${response.statusText}`);
    }

    let result = response.data;
    document.getElementById('game-count').textContent = result.game_count;
    document.getElementById('high-score').textContent = result.high_score;   
}

/******************************************************************************
 * Main
 *****************************************************************************/

 // Prepare form
let form = document.getElementById('guess-form');
form.addEventListener('submit', function (event) {
    event.preventDefault();
    let word = this.elements.word.value;
    this.reset();
    /* await */ checkWord(word);  // also updates scoreboard
});
document.getElementById('word').focus();

// Start the timer
let seconds = START_SECONDS;
let timer = document.getElementById('timer');
timer.textContent = seconds;
let intervalId = setInterval(function () {
    seconds--;
    timer.textContent = seconds;
    if (seconds === 0) {
        // Stop timer
        clearInterval(intervalId);

        // Disable form input
        let but = document.getElementsByTagName('button')[0];
        but.setAttribute('disabled', true);

        // Record game
        let score = Number( document.getElementById('score').textContent );
        recordGame(score);
    }
}, 1000);