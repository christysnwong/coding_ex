from flask import Flask, flash, jsonify, render_template, \
    redirect, request, session
from flask_debugtoolbar import DebugToolbarExtension

from boggle import Boggle


app = Flask(__name__)


# DebugToolbar
app.debug = True
app.config['SECRET_KEY'] = 'Give me more cheese!! Pleeze!!!'
app.config['DEBUG_TB_INTERCEPT_REDIRECTS'] = False
toolbar = DebugToolbarExtension(app)


boggle = Boggle()


@app.route('/')
def home():
    session['board'] = boggle.make_board()
    if 'game_count' not in session:
        session['game_count'] = 0
        session['high_score'] = 0

    return render_template('home.html')


@app.route('/check-word')
def check_word():
    word = request.args['word']
    status = boggle.check_valid_word(session['board'], word)

    return jsonify({ 'status': status })


# Update game statistics
@app.route('/record-game', methods=['POST'])
def post_game():
    score = request.json['score']
    session['high_score'] = max(session['high_score'], score)
    session['game_count'] = session['game_count'] + 1
    result = dict(session)
    del result['board']

    response = jsonify(result)

    return response